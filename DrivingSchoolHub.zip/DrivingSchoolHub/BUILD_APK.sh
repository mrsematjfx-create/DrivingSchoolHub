#!/bin/bash
# ============================================================
# Driving School Hub - One-click APK Builder
# Requirements: Java 17+, Android SDK Command-line Tools
# ============================================================
set -e

echo "============================================"
echo "  DRIVING SCHOOL HUB - APK Builder"
echo "============================================"

# Check Java
if ! command -v java &> /dev/null; then
    echo "ERROR: Java not found. Install JDK 17 from https://adoptium.net"
    exit 1
fi
echo "✅ Java: $(java -version 2>&1 | head -1)"

# Check ANDROID_HOME
if [ -z "$ANDROID_HOME" ]; then
    echo ""
    echo "ERROR: ANDROID_HOME not set."
    echo "Download Android command-line tools from:"
    echo "  https://developer.android.com/studio#command-tools"
    echo ""
    echo "Then run:"
    echo "  export ANDROID_HOME=/path/to/android-sdk"
    echo "  \$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager \"platform-tools\" \"platforms;android-34\" \"build-tools;34.0.0\""
    exit 1
fi
echo "✅ ANDROID_HOME: $ANDROID_HOME"

# Download Gradle wrapper if missing
if ! command -v gradle &> /dev/null; then
    echo ""
    echo "Gradle not found. Using Gradle Wrapper (will auto-download)..."
    if [ ! -f ./gradle/wrapper/gradle-wrapper.jar ]; then
        echo "Downloading gradle-wrapper.jar..."
        curl -L "https://raw.githubusercontent.com/gradle/gradle/v8.0.0/gradle/wrapper/gradle-wrapper.jar" \
             -o gradle/wrapper/gradle-wrapper.jar 2>/dev/null || \
        wget -q "https://raw.githubusercontent.com/gradle/gradle/v8.0.0/gradle/wrapper/gradle-wrapper.jar" \
             -O gradle/wrapper/gradle-wrapper.jar
    fi
    chmod +x gradlew
    ./gradlew assembleDebug
else
    gradle assembleDebug
fi

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
    echo ""
    echo "✅ SUCCESS! APK built:"
    echo "   $(pwd)/$APK_PATH"
    echo ""
    echo "Install on your phone:"
    echo "   adb install $APK_PATH"
else
    echo "❌ Build failed. Check errors above."
    exit 1
fi
