# 🚗 Driving School Hub

A native Android app for finding registered driving schools across all 9 South African provinces.

## Features
- 📍 Real-time GPS location on OpenStreetMap
- 🏫 Green pin markers for each registered driving school
- 🔍 Filter by province (all 9 covered)
- 📋 School details: phone, email, hours, services, rating, registration number
- 📞 One-tap Call & Directions buttons
- 🏠 Home screen with province browse cards
- 🛠️ Tools screen to register new schools

## How to Build the APK (No Android Studio needed)

### Requirements
| Tool | Version | Download |
|------|---------|----------|
| Java JDK | 17+ | https://adoptium.net |
| Android SDK | API 34 | https://developer.android.com/studio#command-tools |

### Steps

**1. Install Android SDK command-line tools**
```bash
# Download from https://developer.android.com/studio#command-tools
# Extract and set ANDROID_HOME:
export ANDROID_HOME=~/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
```

**2. Accept licenses & install SDK components**
```bash
sdkmanager --licenses
sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools"
```

**3. Build the APK**
```bash
cd DrivingSchoolHub
chmod +x BUILD_APK.sh
./BUILD_APK.sh
```

**4. Install on your Android phone**
```bash
# Enable USB debugging on your phone, then:
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Project Structure
```
DrivingSchoolHub/
├── app/src/main/
│   ├── java/com/dsh/drivinschoolhub/
│   │   ├── MainActivity.java        # Host activity + bottom nav
│   │   ├── MapFragment.java         # OSMDroid map + markers
│   │   ├── HomeFragment.java        # Welcome + province cards
│   │   ├── ToolsFragment.java       # Register school, contact
│   │   ├── SchoolDetailBottomSheet  # Tap a pin → details
│   │   ├── SchoolRepository.java    # Data layer
│   │   └── model/DrivingSchool.java # Data model
│   ├── assets/schools.json          # All registered schools
│   └── res/                         # Layouts, colors, icons
├── BUILD_APK.sh                     # One-click build script
└── README.md
```

## Adding More Schools
Edit `app/src/main/assets/schools.json` — copy any existing entry and fill in the new school's details. Each school needs coordinates (latitude/longitude).

## Map Technology
Uses **OSMDroid** (OpenStreetMap) — no Google Maps API key required!
