package com.dsh.drivinschoolhub;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.dsh.drivinschoolhub.model.DrivingSchool;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    private MapFragment mapFragment = new MapFragment();
    private HomeFragment homeFragment = new HomeFragment();
    private ToolsFragment toolsFragment = new ToolsFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SchoolRepository.getInstance().loadSchools(this);
        loadFragment(homeFragment);
        BottomNavigationView nav = findViewById(R.id.bottom_nav);
        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) { loadFragment(homeFragment); return true; }
            if (id == R.id.nav_map)  { loadFragment(mapFragment);  return true; }
            if (id == R.id.nav_tools){ loadFragment(toolsFragment); return true; }
            return false;
        });
    }
    private void loadFragment(Fragment f) {
        getSupportFragmentManager().beginTransaction()
            .replace(R.id.fragment_container, f).commit();
    }
    public void navigateToMap(String province) {
        mapFragment.setProvinceFilter(province);
        BottomNavigationView nav = findViewById(R.id.bottom_nav);
        nav.setSelectedItemId(R.id.nav_map);
        loadFragment(mapFragment);
    }
    public void showSchoolDetail(DrivingSchool school) {
        SchoolDetailBottomSheet.newInstance(school)
            .show(getSupportFragmentManager(), "detail");
    }
}
