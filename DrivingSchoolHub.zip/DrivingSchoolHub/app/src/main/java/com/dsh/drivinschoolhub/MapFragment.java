package com.dsh.drivinschoolhub;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.dsh.drivinschoolhub.model.DrivingSchool;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import org.osmdroid.api.IMapController;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;
import java.util.List;

public class MapFragment extends Fragment {
    private MapView mapView;
    private MyLocationNewOverlay locationOverlay;
    private IMapController mapController;
    private String currentFilter = "All Provinces";

    public MapFragment() {}

    public void setProvinceFilter(String province) {
        currentFilter = province;
        if (mapView != null) refreshMarkers();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle saved) {
        Configuration.getInstance().setUserAgentValue(requireActivity().getPackageName());
        View view = inflater.inflate(R.layout.fragment_map, container, false);
        mapView = view.findViewById(R.id.map_view);
        mapView.setTileSource(TileSourceFactory.MAPNIK);
        mapView.setMultiTouchControls(true);
        mapView.setBuiltInZoomControls(false);
        mapController = mapView.getController();
        mapController.setZoom(6.0);
        mapController.setCenter(new GeoPoint(-29.0, 25.0));

        locationOverlay = new MyLocationNewOverlay(new GpsMyLocationProvider(requireContext()), mapView);
        locationOverlay.enableMyLocation();
        mapView.getOverlays().add(locationOverlay);

        setupChips(view);
        refreshMarkers();

        FloatingActionButton fab = view.findViewById(R.id.fab_my_location);
        fab.setOnClickListener(v -> centerOnMe());
        return view;
    }

    private void setupChips(View view) {
        ChipGroup cg = view.findViewById(R.id.chip_group_filter);
        for (String p : SchoolRepository.getInstance().getProvinces()) {
            Chip chip = new Chip(requireContext());
            chip.setText(p);
            chip.setCheckable(true);
            chip.setChecked(p.equals(currentFilter));
            chip.setOnClickListener(v -> {
                currentFilter = p;
                for (int i = 0; i < cg.getChildCount(); i++)
                    ((Chip)cg.getChildAt(i)).setChecked(((Chip)cg.getChildAt(i)).getText().toString().equals(p));
                refreshMarkers();
                zoomTo(p);
            });
            cg.addView(chip);
        }
    }

    private void refreshMarkers() {
        mapView.getOverlays().removeIf(o -> o instanceof Marker);
        List<DrivingSchool> schools = currentFilter.equals("All Provinces")
            ? SchoolRepository.getInstance().loadSchools(requireContext())
            : SchoolRepository.getInstance().filterByProvince(currentFilter);
        for (DrivingSchool s : schools) {
            Marker m = new Marker(mapView);
            m.setPosition(new GeoPoint(s.latitude, s.longitude));
            m.setTitle(s.name);
            m.setIcon(makeMarkerIcon());
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            m.setOnMarkerClickListener((marker, mv) -> {
                if (getActivity() instanceof MainActivity)
                    ((MainActivity)getActivity()).showSchoolDetail(s);
                return true;
            });
            mapView.getOverlays().add(m);
        }
        mapView.invalidate();
    }

    private Drawable makeMarkerIcon() {
        int sz = 80;
        Bitmap bmp = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#1B5E20"));
        c.drawCircle(sz/2f, sz/2f-10, sz/2f-8, p);
        Path path = new Path();
        path.moveTo(sz/2f-10, sz/2f+4); path.lineTo(sz/2f+10, sz/2f+4); path.lineTo(sz/2f, sz-4); path.close();
        c.drawPath(path, p);
        p.setColor(Color.WHITE); c.drawCircle(sz/2f, sz/2f-10, sz/2f-20, p);
        p.setColor(Color.parseColor("#1B5E20")); p.setTextSize(26); p.setTextAlign(Paint.Align.CENTER); p.setFakeBoldText(true);
        c.drawText("S", sz/2f, sz/2f-2, p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private void centerOnMe() {
        if (locationOverlay.getMyLocation() != null) {
            mapController.animateTo(locationOverlay.getMyLocation());
            mapController.setZoom(14.0);
        } else if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 100);
        }
    }

    private void zoomTo(String province) {
        GeoPoint center; double zoom = 9.0;
        switch (province) {
            case "Gauteng": center = new GeoPoint(-26.2041, 28.0473); zoom=10; break;
            case "Western Cape": center = new GeoPoint(-33.9249, 18.4241); break;
            case "KwaZulu-Natal": center = new GeoPoint(-29.8587, 31.0218); break;
            case "Eastern Cape": center = new GeoPoint(-33.0153, 27.9116); break;
            case "Limpopo": center = new GeoPoint(-23.9045, 29.4688); break;
            case "Mpumalanga": center = new GeoPoint(-25.4745, 30.9700); break;
            case "North West": center = new GeoPoint(-25.6672, 27.2427); break;
            case "Free State": center = new GeoPoint(-29.1210, 26.2041); break;
            case "Northern Cape": center = new GeoPoint(-28.7282, 24.7499); break;
            default: center = new GeoPoint(-29.0, 25.0); zoom=6; break;
        }
        mapController.animateTo(center); mapController.setZoom(zoom);
    }

    @Override public void onResume() { super.onResume(); mapView.onResume(); locationOverlay.enableMyLocation(); }
    @Override public void onPause() { super.onPause(); mapView.onPause(); locationOverlay.disableMyLocation(); }
    @Override public void onRequestPermissionsResult(int code, @NonNull String[] perms, @NonNull int[] res) {
        if (code==100 && res.length>0 && res[0]==PackageManager.PERMISSION_GRANTED) { locationOverlay.enableMyLocation(); centerOnMe(); }
    }
}
