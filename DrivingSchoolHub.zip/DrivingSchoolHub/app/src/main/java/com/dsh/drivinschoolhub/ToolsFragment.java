package com.dsh.drivinschoolhub;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class ToolsFragment extends Fragment {
    public ToolsFragment() {}
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup c, Bundle b) {
        View view = inflater.inflate(R.layout.fragment_tools, c, false);
        view.findViewById(R.id.btn_register_school).setOnClickListener(v ->
            Toast.makeText(requireContext(), "Registration: admin@drivinschoolhub.co.za", Toast.LENGTH_LONG).show());
        view.findViewById(R.id.btn_about).setOnClickListener(v ->
            Toast.makeText(requireContext(), "Driving School Hub v1.0 — All 9 SA Provinces", Toast.LENGTH_SHORT).show());
        view.findViewById(R.id.btn_contact).setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:admin@drivinschoolhub.co.za"));
            i.putExtra(Intent.EXTRA_SUBJECT, "DSH Enquiry"); startActivity(i);
        });
        return view;
    }
}
