package com.dsh.drivinschoolhub.model;
import java.io.Serializable;
public class DrivingSchool implements Serializable {
    public String id, name, address, province, phone, email, website;
    public double latitude, longitude;
    public boolean offersTheory, offersPractical, offersYardTest, offersK53;
    public String rating, registrationNumber, operatingHours;
    public int priceRange;
    public String getPriceLabel() {
        switch (priceRange) {
            case 1: return "Budget"; case 2: return "Mid-Range"; case 3: return "Premium";
            default: return "N/A";
        }
    }
}
