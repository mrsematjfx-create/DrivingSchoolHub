package com.dsh.drivinschoolhub;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.dsh.drivinschoolhub.model.DrivingSchool;
import com.google.android.material.button.MaterialButton;
import java.util.List;

public class HomeFragment extends Fragment {
    public HomeFragment() {}
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup c, Bundle b) {
        View view = inflater.inflate(R.layout.fragment_home, c, false);
        SchoolRepository repo = SchoolRepository.getInstance();
        ((TextView)view.findViewById(R.id.tv_total_schools)).setText(String.valueOf(repo.getTotalCount()));
        ((TextView)view.findViewById(R.id.tv_province_count)).setText("9");
        view.findViewById(R.id.btn_find_near_me).setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity)
                ((MainActivity)getActivity()).navigateToMap("All Provinces");
        });
        LinearLayout container = view.findViewById(R.id.provinces_container);
        List<String> provinces = repo.getProvinces();
        provinces = new java.util.ArrayList<>(provinces);
        provinces.remove("All Provinces");
        for (String province : provinces) {
            View card = inflater.inflate(R.layout.item_province_card, container, false);
            ((TextView)card.findViewById(R.id.tv_province_name)).setText(province);
            int count = repo.filterByProvince(province).size();
            ((TextView)card.findViewById(R.id.tv_school_count)).setText(count + " school" + (count!=1?"s":""));
            card.setOnClickListener(v -> {
                if (getActivity() instanceof MainActivity)
                    ((MainActivity)getActivity()).navigateToMap(province);
            });
            container.addView(card);
        }
        return view;
    }
}
