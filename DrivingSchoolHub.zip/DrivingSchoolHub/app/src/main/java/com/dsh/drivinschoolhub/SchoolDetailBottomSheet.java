package com.dsh.drivinschoolhub;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import com.dsh.drivinschoolhub.model.DrivingSchool;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

public class SchoolDetailBottomSheet extends BottomSheetDialogFragment {
    private static final String ARG = "school";
    public static SchoolDetailBottomSheet newInstance(DrivingSchool s) {
        SchoolDetailBottomSheet f = new SchoolDetailBottomSheet();
        Bundle b = new Bundle(); b.putSerializable(ARG, s); f.setArguments(b); return f;
    }
    @Override
    public View onCreateView(LayoutInflater inf, ViewGroup c, Bundle b) {
        View view = inf.inflate(R.layout.bottom_sheet_school, c, false);
        DrivingSchool s = getArguments() != null ? (DrivingSchool)getArguments().getSerializable(ARG) : null;
        if (s == null) return view;
        ((TextView)view.findViewById(R.id.tv_school_name)).setText(s.name);
        ((TextView)view.findViewById(R.id.tv_address)).setText("📍 " + s.address);
        ((TextView)view.findViewById(R.id.tv_province)).setText(s.province);
        ((TextView)view.findViewById(R.id.tv_rating)).setText("⭐ " + s.rating + " / 5.0");
        ((TextView)view.findViewById(R.id.tv_phone)).setText("📞 " + s.phone);
        ((TextView)view.findViewById(R.id.tv_email)).setText("✉ " + s.email);
        ((TextView)view.findViewById(R.id.tv_hours)).setText("🕐 " + s.operatingHours);
        ((TextView)view.findViewById(R.id.tv_reg_number)).setText("Reg: " + s.registrationNumber);
        ((TextView)view.findViewById(R.id.tv_price)).setText("💰 " + s.getPriceLabel());
        ChipGroup cg = view.findViewById(R.id.cg_services);
        addChip(cg, "Theory", s.offersTheory);
        addChip(cg, "Practical", s.offersPractical);
        addChip(cg, "Yard Test", s.offersYardTest);
        addChip(cg, "K53", s.offersK53);
        view.findViewById(R.id.btn_call).setOnClickListener(v ->
            startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + s.phone))));
        view.findViewById(R.id.btn_directions).setOnClickListener(v ->
            startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse("geo:" + s.latitude + "," + s.longitude + "?q=" + s.latitude + "," + s.longitude + "(" + Uri.encode(s.name) + ")"))));
        return view;
    }
    private void addChip(ChipGroup g, String label, boolean on) {
        Chip chip = new Chip(requireContext());
        chip.setText(label); chip.setCheckable(false);
        if (on) { chip.setChipBackgroundColorResource(R.color.green_chip_bg); chip.setTextColor(getResources().getColor(R.color.white)); }
        else chip.setAlpha(0.4f);
        g.addView(chip);
    }
}
