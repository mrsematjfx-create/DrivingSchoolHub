package com.dsh.drivinschoolhub;
import android.content.Context;
import com.dsh.drivinschoolhub.model.DrivingSchool;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class SchoolRepository {
    private static SchoolRepository instance;
    private List<DrivingSchool> allSchools = new ArrayList<>();
    public static SchoolRepository getInstance() {
        if (instance == null) instance = new SchoolRepository();
        return instance;
    }
    public List<DrivingSchool> loadSchools(Context ctx) {
        if (!allSchools.isEmpty()) return allSchools;
        try {
            InputStream is = ctx.getAssets().open("schools.json");
            byte[] buf = new byte[is.available()]; is.read(buf); is.close();
            Type t = new TypeToken<List<DrivingSchool>>(){}.getType();
            allSchools = new Gson().fromJson(new String(buf, StandardCharsets.UTF_8), t);
        } catch (IOException e) { e.printStackTrace(); }
        return allSchools;
    }
    public List<DrivingSchool> filterByProvince(String province) {
        if (province == null || province.equals("All Provinces")) return allSchools;
        List<DrivingSchool> out = new ArrayList<>();
        for (DrivingSchool s : allSchools) if (s.province.equalsIgnoreCase(province)) out.add(s);
        return out;
    }
    public int getTotalCount() { return allSchools.size(); }
    public List<String> getProvinces() {
        return Arrays.asList("All Provinces","Gauteng","Western Cape","KwaZulu-Natal",
            "Eastern Cape","Limpopo","Mpumalanga","North West","Free State","Northern Cape");
    }
}
